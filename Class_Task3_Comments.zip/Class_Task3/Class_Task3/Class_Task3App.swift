//
//  Class_Task3App.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/6/25.
//

import SwiftUI

@main
struct Class_Task3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
