//
//  ContentView.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/6/25.
//

import SwiftUI

// Define a custom button style for primary buttons
struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0) // Scale down slightly when pressed
    }
}

// Define a custom button style for secondary buttons
struct ScondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .foregroundColor(.white)
            .background(Color.red)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0) // Scale down slightly when pressed
    }
}

// Define the main content view
struct ContentView: View {
    var body: some View {
        ZStack { // Use ZStack to layer views
            Color.gray.opacity(0.4)
                .ignoresSafeArea() // Extend background color to entire screen
            
            VStack { // Use VStack to arrange elements vertically
                Image(systemName: "person.circle") // Use system icon for profile
                    .resizable() // Allow resizing of image
                    .frame(width: 80, height: 80)
                    .foregroundStyle(.white)
                    .shadow(radius: 7) // Apply shadow effect
                
                Text("Tahani Ayman")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("Welcome to SwiftUI!")
                    .padding(.top)
                
                Spacer()
                
                HStack { // Use HStack to arrange buttons horizontally
                    Button("Primary Button"){}
                        .buttonStyle(PrimaryButtonStyle()) // Apply custom primary button style
                    
                    Button("Scondary Button"){}
                        .buttonStyle(ScondaryButtonStyle()) // Apply custom secondary button style
                }
            }
            .padding()
        }
    }
}


#Preview {
    ContentView()
}
