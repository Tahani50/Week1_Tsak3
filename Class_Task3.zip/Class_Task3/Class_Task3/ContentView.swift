//
//  ContentView.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/6/25.
//

import SwiftUI

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

struct ScondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .foregroundColor(.white)
            .background(Color.red)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

struct ContentView: View {
    var body: some View {
        ZStack {
            Color.gray.opacity(0.4)
                .ignoresSafeArea()
            VStack {
                Image(systemName: "person.circle")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .foregroundStyle(.white)
                    .shadow(radius: 7)
                
                Text("Tahani Ayman")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("Welcome to SwiftUI!")
                    .padding(.top)
                Spacer()
                HStack {
                    Button("Primary Button"){}
                        .buttonStyle(PrimaryButtonStyle())
                        
                    
                    Button("Scondary Button"){}
                        .buttonStyle(ScondaryButtonStyle())
                    
                }
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
